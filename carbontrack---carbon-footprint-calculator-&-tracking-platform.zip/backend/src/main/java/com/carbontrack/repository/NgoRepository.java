package com.carbontrack.entity;

package com.carbontrack.repository;

import com.carbontrack.entity.Ngo;
import com.carbontrack.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface NgoRepository extends JpaRepository<Ngo, Long> {
    Optional<Ngo> findByUser(User user);
    Optional<Ngo> findByUserId(Long userId);
}
